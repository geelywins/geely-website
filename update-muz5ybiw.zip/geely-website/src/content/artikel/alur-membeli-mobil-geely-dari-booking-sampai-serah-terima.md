---
title: "Alur Membeli Mobil Geely dari Booking sampai Serah Terima"
description: "Panduan alur membeli mobil Geely dari konsultasi, test drive, simulasi, booking, kredit sampai serah terima, lengkap dengan checklist yang mudah diikuti."
date: 2026-10-07
category: "Tips Membeli"
tags: ["alur membeli mobil geely", "cara beli mobil geely", "booking geely", "serah terima mobil", "dealer geely jakarta", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: true
---

Alur membeli mobil Geely terdiri dari tujuh langkah: konsultasi kebutuhan, test drive, simulasi harga dan cicilan, booking unit, pengajuan pembayaran atau kredit, administrasi, lalu serah terima. Dengan urutan ini, Anda tahu apa yang harus disiapkan di setiap tahap, sehingga prosesnya terasa lebih tenang dan tidak membingungkan.

Saya Wins, Sales Consultant Geely yang melayani area Jakarta dan BSD City. Banyak calon pembeli bertanya, "Saya harus mulai dari mana?" Artikel ini menjawabnya dengan bahasa sederhana. Detail aturan bisa berbeda antar waktu dan antar dealer, jadi anggap panduan ini sebagai peta umum. Untuk data terbaru, tanyakan langsung ke sales.

## Gambaran singkat tujuh langkah

Sebelum masuk ke detail, lihat dulu ringkasannya dalam tabel berikut. Tabel ini bisa Anda simpan sebagai pegangan.

| Langkah | Yang dilakukan | Yang perlu Anda siapkan |
|---|---|---|
| 1. Konsultasi | Menentukan model dan varian | Kebutuhan harian dan jumlah penumpang |
| 2. Test drive | Mencoba mobil langsung | SIM yang masih berlaku |
| 3. Simulasi | Membandingkan skema pembayaran | Rencana uang muka dan tenor |
| 4. Booking | Mengamankan unit dan warna | Identitas dan bukti pembayaran booking |
| 5. Pembayaran atau kredit | Tunai atau pengajuan pembiayaan | Dokumen sesuai arahan sales |
| 6. Administrasi | Dealer mengurus berkas kendaraan | Kelengkapan data diri |
| 7. Serah terima | Cek unit lalu terima kunci | Waktu luang dan pendamping bila perlu |

## Langkah 1: Konsultasi dan memilih model

Mulailah dari kebutuhan, bukan dari model. Tuliskan berapa orang yang biasa naik mobil, berapa jauh jarak harian, dan apakah ada tempat parkir yang bisa dipasangi pengisi daya. Dari jawaban itu, pilihan akan mengerucut dengan sendirinya.

Untuk pemakaian di kota, [Geely EX2](/model/geely-ex2/) layak dipertimbangkan karena ukurannya ringkas. Jika keluarga Anda butuh kabin lebih lega, lihat [Geely EX5](/model/geely-ex5/). Bila bingung memilih di antara keduanya, baca [perbandingan Geely EX2 dan EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/) terlebih dahulu.

## Langkah 2: Test drive

Foto dan spesifikasi tidak bisa menggantikan pengalaman duduk di belakang kemudi. Karena itu, jadwalkan test drive sebelum membicarakan angka. Perhatikan posisi duduk, jarak pandang, respons pedal, dan kemudahan memakai layar.

Ajak anggota keluarga yang akan sering memakai mobil. Cara mengatur jadwalnya sudah saya tulis di [panduan test drive Geely di Jakarta dan BSD City](/artikel/cara-test-drive-geely/). Jika Anda berminat pada varian tertentu, ada juga [checklist test drive Geely EX2 Max](/artikel/test-drive-geely-ex2-max-checklist-yang-perlu-dicek/).

## Langkah 3: Simulasi harga dan cicilan

Setelah cocok, mintalah rincian simulasi dari sales. Biasanya simulasi memuat harga kendaraan, uang muka, lama tenor, dan perkiraan angsuran. Minta lebih dari satu skema supaya bisa dibandingkan.

Beberapa hal yang sebaiknya Anda tanyakan:

- Apa saja yang sudah termasuk dalam harga yang disebutkan.
- Biaya tambahan apa yang mungkin muncul di luar harga kendaraan.
- Apakah ada program atau promo yang sedang berlaku.
- Bagaimana asuransi dihitung dalam skema yang ditawarkan.

Penjelasan cara membaca angka cicilan ada di [simulasi kredit mobil listrik: DP, tenor, dan cicilan](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/). Untuk promo yang sedang berjalan, cek halaman [promo Geely](/promo/) atau tanyakan ke sales karena sifatnya bisa berubah.

## Langkah 4: Booking unit

Booking adalah tanda keseriusan Anda untuk mengamankan unit. Pada tahap ini Anda memilih varian dan warna, lalu mengikuti ketentuan booking dari dealer. Nominal dan aturannya bisa berbeda, jadi tanyakan secara jelas sebelum membayar.

Pastikan Anda menerima bukti pembayaran dan dokumen booking. Simpan keduanya dengan rapi. Tanyakan juga perkiraan waktu ketersediaan unit, karena stok varian dan warna tidak selalu sama. Tips tambahan ada di [tips booking dan negosiasi Geely EX2 Max](/artikel/tips-booking-dan-negosiasi-geely-ex2-max/).

## Langkah 5: Pembayaran tunai atau pengajuan kredit

Jika membeli tunai, Anda cukup mengikuti tagihan dari dealer. Jika memakai kredit, perusahaan pembiayaan akan memeriksa data Anda terlebih dahulu. Proses ini membutuhkan waktu yang berbeda-beda, tergantung kelengkapan berkas dan kebijakan pembiayaan.

Dokumen yang umumnya diminta adalah identitas diri dan bukti penghasilan. Daftar pastinya bisa berbeda, jadi minta daftar resmi dari sales sejak awal. Dengan begitu Anda tidak bolak-balik melengkapi berkas.

## Langkah 6: Administrasi kendaraan

Setelah pembayaran atau persetujuan kredit selesai, dealer mengurus administrasi kendaraan. Anda tidak perlu mengurus sendiri semuanya, tetapi tetap pantau perkembangannya. Tanyakan kapan perkiraan unit siap dan apa saja yang masih dibutuhkan dari Anda.

Untuk mobil listrik, ada baiknya Anda juga menanyakan soal pajak dan insentif yang berlaku. Aturannya bisa berubah, sehingga informasi terbaru dari sales lebih dapat diandalkan. Anda bisa membaca gambaran umumnya di [pajak dan insentif mobil listrik untuk Geely EX2 Max](/artikel/pajak-dan-insentif-mobil-listrik-untuk-geely-ex2-max/).

## Langkah 7: Pengecekan unit dan serah terima

Ini momen yang paling ditunggu. Sebelum menerima kunci, luangkan waktu untuk memeriksa unit dengan teliti. Jangan merasa sungkan, karena pengecekan ini hak Anda sebagai pembeli.

### Checklist saat serah terima

- Periksa kondisi bodi dan cat dari semua sisi.
- Pastikan aksesori standar dan kelengkapan sesuai kesepakatan.
- Coba layar, pendingin udara, kamera, dan fitur utama lainnya.
- Pastikan kabel pengisi daya yang menjadi bawaan unit sudah ada.
- Terima buku manual, kartu garansi, dan dokumen kendaraan.
- Minta penjelasan singkat cara memakai fitur penting.

### Belajar mengisi daya sejak hari pertama

Mintalah sales menjelaskan cara menyambungkan kabel dan membaca indikator pengisian. Jika Anda berencana memasang pengisi daya di rumah, baca dulu [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/). Jangan lupa tanyakan informasi garansi, misalnya lewat [garansi baterai dan mobil Geely EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/).

## Kesalahan yang sering terjadi

Beberapa hal kecil sering membuat proses jadi lebih lama. Kenali supaya Anda bisa menghindarinya.

- Memilih warna dan varian tanpa mengecek ketersediaan unit.
- Membayar booking tanpa meminta bukti tertulis.
- Tidak membandingkan beberapa skema cicilan.
- Terburu-buru saat serah terima sehingga lupa mengecek kelengkapan.
- Belum menyiapkan tempat pengisian daya sebelum mobil tiba.

## Pertanyaan yang sering diajukan

### Berapa lama proses dari booking sampai serah terima?
Lamanya bergantung pada ketersediaan unit, metode pembayaran, dan proses administrasi. Tanyakan perkiraan waktu terbaru ke sales sebelum Anda melakukan booking.

### Apakah test drive wajib dilakukan sebelum booking?
Tidak wajib, tetapi sangat disarankan. Dengan mencoba langsung, Anda lebih yakin bahwa mobilnya cocok untuk kebutuhan harian.

### Dokumen apa saja yang perlu disiapkan?
Umumnya identitas diri, dan untuk kredit ditambah bukti penghasilan. Daftar lengkapnya bisa berubah, jadi minta daftar terbaru dari sales.

### Bisakah saya membandingkan beberapa skema cicilan?
Bisa, dan itu sangat dianjurkan. Minta sales menyiapkan lebih dari satu simulasi dengan uang muka dan tenor yang berbeda.

### Apa yang harus saya cek saat serah terima?
Cek bodi, aksesori standar, fitur layar dan pendingin, kabel pengisi daya, serta dokumen. Pastikan juga Anda mendapat penjelasan cara memakai fitur utama.

### Apakah saya perlu memasang pengisi daya di rumah?
Tidak selalu, tetapi banyak pemilik merasa terbantu karena bisa mengisi saat malam. Konsultasikan kondisi listrik rumah Anda dengan teknisi dan tanyakan arahan dari sales.

## Kesimpulan

Membeli mobil baru terasa jauh lebih mudah jika Anda tahu urutannya: konsultasi, test drive, simulasi, booking, pembayaran, administrasi, dan serah terima. Tanyakan hal yang belum jelas di setiap tahap, simpan semua bukti, dan jangan terburu-buru saat memeriksa unit.

Jika Anda siap memulai, [chat saya lewat WhatsApp di halaman kontak](/kontak/). Saya akan bantu mengatur jadwal test drive, menyiapkan simulasi, dan memandu Anda sampai mobilnya diserahkan.
