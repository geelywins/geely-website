---
title: "Geely EX2: Mobil Listrik Kompak untuk Harian dan Kota"
description: "Kenali Geely EX2, mobil listrik kompak untuk kota: baterai, ruang kabin, cara pakai harian, dan hal yang perlu dicek sebelum test drive. Yuk baca dulu."
date: 2026-10-07
category: "Model Geely"
tags: ["geely ex2", "mobil listrik geely", "geely ev", "geely indonesia", "mobil listrik kompak", "mobil listrik jakarta", "ev geely jakarta", "test drive geely"]
draft: true
---

Geely EX2 adalah mobil listrik kompak yang dirancang untuk pemakaian harian di kota besar seperti Jakarta dan BSD. Ukurannya ringkas sehingga mudah parkir, kabinnya muat lima penumpang, dan biaya energinya biasanya lebih ringan dibanding mobil bensin. Artikel ini merangkum hal penting sebelum Anda memutuskan.

## Mengenal Geely EX2 secara singkat

[Geely EX2](/model/geely-ex2/) masuk kelompok mobil listrik kompak perkotaan. Mobil ini cocok untuk Anda yang ingin beralih dari bensin tanpa harus memilih kendaraan yang besar. Ukurannya yang ringkas membuatnya lincah di jalan padat dan gang perumahan.

Di Indonesia, EX2 tersedia dalam beberapa varian, di antaranya Pro dan Max. Keduanya memakai penggerak listrik yang sama, sedangkan perbedaannya ada pada kelengkapan fitur. Bila Anda ingin membandingkan keduanya, baca [perbedaan Geely EX2 Pro dan EX2 Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).

## Data utama yang sudah terverifikasi

Berikut data varian Max yang kami pegang. Angka adalah klaim pabrikan dan bisa berubah, jadi konfirmasi ke sales untuk informasi terbaru.

| Komponen | Keterangan |
|---|---|
| Baterai | LFP 40,8 kWh |
| Motor listrik | 85 kW, torsi 150 Nm |
| Klaim jarak tempuh | 395 km (siklus NEDC) |
| Pengisian cepat DC | 30-80% sekitar 25 menit |
| Pengisian AC | 10-100% sekitar 6,5 jam |
| Layar tengah | 14,6 inci |
| Bagasi | 375 liter, plus frunk 70 liter |
| Kapasitas | 5 penumpang |

Penjelasan arti tiap angka ada di [spesifikasi lengkap Geely EX2 Max](/artikel/spesifikasi-lengkap-geely-ex2-max/). Data yang belum kami verifikasi, seperti dimensi eksak, sengaja tidak ditulis di sini.

## Kelebihan untuk pemakaian harian

Ada beberapa alasan EX2 enak dipakai setiap hari. Berikut yang paling sering dirasakan pemilik mobil listrik kompak.

- Ukuran ringkas membuat parkir paralel dan putar balik terasa lebih mudah.
- Tenaga motor listrik terasa responsif sejak pedal diinjak, cocok untuk jalan kota.
- Biaya energi harian umumnya lebih hemat dibanding BBM, terutama bila mengisi daya di rumah.
- Kabin bernuansa modern dengan layar besar yang memudahkan akses peta dan pengaturan.
- Ada frunk atau bagasi depan untuk menyimpan kabel pengisi daya dan barang kecil.

Untuk gambaran kenyamanan kabin, baca [ambient light dan layar 14,6 inci Geely EX2 Max](/artikel/ambient-light-256-warna-dan-layar-14-6-inci-geely-ex2-max/).

## Cocok untuk siapa saja?

EX2 paling pas untuk beberapa kelompok pengguna. Cocokkan dengan kebiasaan Anda sebelum memilih.

### Pekerja kota

Rute rumah ke kantor yang tidak terlalu jauh sangat sesuai dengan karakter EX2. Anda bisa mengisi daya malam hari lalu berangkat dengan baterai penuh. Lihat juga [Geely EX2 Max di macet Jakarta dan BSD](/artikel/geely-ex2-max-di-macet-jakarta-dan-bsd/).

### Keluarga muda dan pengguna pertama

EX2 bisa menjadi mobil kedua keluarga atau mobil listrik pertama. Bacaan yang relevan adalah [Geely EX2 Max untuk keluarga muda](/artikel/geely-ex2-max-untuk-keluarga-muda/). Kemudahan mengemudinya juga dibahas di artikel untuk pemula dan wanita.

## Dibanding mobil bensin kompak

Perbedaan terbesar terasa pada cara berkendara dan biaya energi. Mobil listrik lebih senyap, tidak bergetar saat berhenti, dan tenaganya langsung tersedia. Di sisi lain, Anda perlu merencanakan pengisian daya, terutama saat bepergian jauh.

Untuk membandingkan biaya secara adil, hitung dari kebiasaan Anda sendiri. Artikel [biaya per km Geely EX2 Max dibanding mobil bensin](/artikel/biaya-per-km-geely-ex2-max-vs-mobil-bensin/) membantu Anda menghitungnya langkah demi langkah. Dengan begitu keputusan Anda berdasarkan data pemakaian nyata, bukan perkiraan semata.

## Pengisian daya sehari-hari

Sebagian besar pengisian dilakukan di rumah pada malam hari lewat pengisian AC. Pengisian cepat DC di SPKLU dipakai saat perjalanan lebih jauh. Pastikan dulu daya listrik dan titik colokan di rumah Anda aman.

Sebelum membeli, tanyakan ke sales mengenai jenis pengisi daya yang tersedia. Panduan lengkapnya ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/). Jika ragu soal instalasi, konsultasikan dengan teknisi listrik yang berpengalaman.

## Hal yang perlu dicek sebelum membeli

Beberapa pertanyaan sederhana membantu Anda mengambil keputusan yang tepat. Jawablah dengan jujur sesuai kondisi sehari-hari.

- Apakah ada tempat mengisi daya di rumah atau kantor?
- Berapa kilometer jarak tempuh Anda dalam sehari?
- Berapa orang yang biasanya ikut di dalam mobil?
- Apakah Anda sering bepergian jauh ke luar kota?

Jika perjalanan jauh cukup sering, bandingkan dengan SUV listrik di [perbandingan Geely EX2 dan EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/). Soal garansi, tanyakan syarat terbaru kepada sales supaya tidak keliru.

## Tips saat test drive

Test drive adalah cara terbaik merasakan EX2. Sebaiknya Anda membawa daftar sederhana agar tidak ada yang terlewat.

1. Cek posisi duduk dan jangkauan setir.
2. Rasakan respons pedal saat berakselerasi pelan dan sedang.
3. Coba parkir untuk menilai kamera dan ukuran mobil.
4. Perhatikan suara kabin dan kenyamanan suspensi.
5. Mainkan layar untuk memastikan menunya mudah dipahami.

Panduan lebih lengkap tersedia di [cara test drive Geely](/artikel/cara-test-drive-geely/). Jadwalkan test drive di waktu jalanan ramai agar Anda merasakan kondisi nyata.

## Pertanyaan yang sering diajukan

### Apakah Geely EX2 cocok untuk dipakai di Jakarta?

Cocok, karena ukurannya ringkas dan mudah bermanuver di jalan padat. Pastikan Anda punya tempat mengisi daya yang nyaman.

### Berapa klaim jarak tempuh EX2?

Untuk varian Max, klaimnya 395 km pada siklus NEDC. Pemakaian nyata biasanya lebih rendah, tergantung kondisi jalan dan gaya mengemudi.

### Berapa lama mengisi daya EX2?

Pengisian cepat DC dari 30 ke 80% sekitar 25 menit, sedangkan AC dari 10 ke 100% sekitar 6,5 jam. Keduanya klaim pabrikan.

### Apakah EX2 muat untuk keluarga?

EX2 memuat lima penumpang dan punya bagasi 375 liter. Untuk kebutuhan ruang lebih besar, pertimbangkan model SUV.

### Berapa harga dan promo EX2 saat ini?

Harga dan promo bisa berubah dari waktu ke waktu. Silakan tanyakan ke sales untuk informasi terbaru.

### Apakah perawatannya rumit?

Tidak serumit mobil bensin karena tidak ada oli mesin. Tetap ikuti jadwal servis berkala yang dianjurkan.

## Kesimpulan

Geely EX2 adalah pilihan menarik bagi Anda yang mencari mobil listrik kompak untuk kota. Ukurannya ringkas, biaya energinya ramah, dan kabinnya terasa modern. Pastikan dulu kebutuhan pengisian daya dan jarak harian Anda sesuai.

Ingin tahu penawaran terbaru? Lihat halaman [promo](/promo/) atau [chat WhatsApp lewat halaman kontak](/kontak/) untuk jadwal test drive dan simulasi. Saya siap membantu Anda.
