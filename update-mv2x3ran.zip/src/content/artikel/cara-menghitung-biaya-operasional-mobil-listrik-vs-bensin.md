---
title: "Cara Menghitung Biaya Operasional Mobil Listrik vs Bensin"
description: "Pelajari cara menghitung biaya operasional mobil listrik dan bensin dengan rumus sederhana dan contoh hitungan, agar bisa membandingkan pakai angka sendiri."
date: 2026-10-07
category: "Tips Membeli"
tags: ["biaya operasional mobil listrik", "biaya per km", "hemat bbm", "tarif listrik", "mobil listrik geely", "geely ev", "geely indonesia", "mobil listrik kompak", "geely ex2"]
draft: true
---

Cara menghitung biaya operasional mobil listrik dibandingkan mobil bensin cukup dengan satu rumus: biaya energi per kilometer, lalu dikalikan jarak tempuh bulanan Anda. Tambahkan perawatan, asuransi, dan pajak agar hasilnya utuh. Hitungan ini memakai angka Anda sendiri, sehingga lebih jujur daripada klaim umum.

Saya Wins, Sales Consultant Geely di Jakarta dan BSD City. Pertanyaan "seberapa hemat mobil listrik?" hampir selalu muncul saat konsultasi. Jawabannya berbeda untuk setiap orang, karena tarif listrik, harga BBM, dan kebiasaan berkendara tidak sama. Karena itu, saya ajak Anda menghitung sendiri langkah demi langkah.

## Mengapa hitungan sendiri lebih akurat

Angka hemat yang beredar di internet biasanya memakai asumsi tertentu. Bisa jadi tarif listriknya berbeda dari tagihan rumah Anda, atau jenis mobil bensin pembandingnya tidak sama dengan mobil Anda saat ini. Akibatnya, hasilnya bisa menyesatkan.

Dengan menghitung sendiri, Anda memakai data yang benar-benar Anda alami. Hasilnya lebih mudah dipercaya, dan Anda bisa memperbaruinya kapan saja jika tarif berubah.

## Rumus biaya energi mobil listrik

Mobil listrik diukur dengan kWh, mirip seperti liter pada mobil bensin. Rumusnya sebagai berikut.

**Biaya per km = tarif listrik per kWh x konsumsi kWh per km**

Konsumsi kWh per km bisa diperkirakan dari kapasitas baterai dibagi jarak tempuh nyata. Sebagai contoh, Geely EX2 Max memakai baterai LFP 40,8 kWh dengan klaim jarak 395 km pada siklus NEDC. Pembagian sederhana keduanya memberi angka sekitar 0,10 kWh per km.

Perlu diingat, klaim NEDC dihasilkan di kondisi terkontrol. Di jalan nyata, jaraknya biasanya lebih pendek, sehingga konsumsi per km menjadi lebih besar. Untuk hitungan yang hati-hati, pakai angka yang lebih konservatif. Pembahasan jarak nyata ada di [jarak tempuh Geely EX2 Max: klaim vs pemakaian harian](/artikel/jarak-tempuh-geely-ex2-max-klaim-vs-pemakaian-harian/).

## Rumus biaya energi mobil bensin

Untuk mobil bensin, rumusnya lebih sederhana.

**Biaya per km = harga BBM per liter : jarak per liter**

Jarak per liter sebaiknya diambil dari catatan pemakaian Anda, misalnya dari jarak yang tertera di odometer dibagi jumlah liter saat mengisi penuh. Angka ini lebih nyata daripada data brosur, apalagi jika Anda sering terjebak macet.

## Contoh hitungan dengan asumsi bayangan

Contoh berikut hanya ilustrasi cara menghitung, bukan data resmi dan bukan janji hasil. Angka satuan uang sengaja dibuat bulat supaya mudah diikuti. Ganti semuanya dengan angka Anda.

**Asumsi (bayangan):**

- Tarif listrik: 1.000 per kWh.
- Harga BBM: 10.000 per liter.
- Konsumsi mobil listrik: 0,15 kWh per km, dibuat lebih besar dari hitungan klaim agar lebih realistis.
- Mobil bensin: 10 km per liter.
- Jarak tempuh: 1.500 km per bulan.

| Komponen | Mobil listrik | Mobil bensin |
|---|---|---|
| Biaya energi per km | 1.000 x 0,15 = 150 | 10.000 : 10 = 1.000 |
| Biaya energi per bulan (1.500 km) | 225.000 | 1.500.000 |

Pada contoh bayangan ini, selisihnya terlihat besar. Namun, jangan menyimpulkan bahwa hasil nyata Anda akan sama. Jika Anda lebih sering mengisi di pengisi daya umum yang tarifnya lebih tinggi, selisihnya akan mengecil.

## Hitung dua skenario pengisian

Biaya listrik tidak selalu satu angka. Karena itu, pisahkan dua skenario.

### Pengisian di rumah

Tarif mengikuti tagihan listrik rumah. Ini biasanya skenario termurah. Panduan persiapannya ada di [cara mengisi daya Geely EX2 Max di rumah](/artikel/cara-mengisi-daya-geely-ex2-max-di-rumah/).

### Pengisian di SPKLU

Tarif ditentukan oleh penyedia layanan dan bisa berubah. Cek harga di aplikasi penyedia sebelum menghitung. Jika Anda memakai keduanya, hitung rata-rata berdasarkan perkiraan porsi pemakaian, misalnya berapa persen di rumah dan berapa persen di luar.

## Biaya lain yang sering terlupa

Energi hanya sebagian dari biaya operasional. Masukkan juga komponen berikut agar perbandingannya adil.

- Perawatan berkala, termasuk ban, rem, dan cairan pendingin.
- Asuransi kendaraan.
- Pajak tahunan dan kebijakan insentif yang berlaku.
- Cicilan dan biaya uang muka jika membeli kredit.
- Biaya pemasangan pengisi daya di rumah, bila Anda memasangnya.

Mobil listrik tidak memakai oli mesin, tetapi bukan berarti bebas perawatan. Perbedaannya dijelaskan di [perawatan mobil listrik: apa yang berbeda dari mobil bensin](/artikel/perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin/). Soal pajak dan insentif, tanyakan ke sales untuk aturan terbaru.

## Langkah praktis menghitung sendiri

1. Catat jarak tempuh bulanan Anda selama dua atau tiga bulan.
2. Lihat tarif listrik pada tagihan rumah, lalu cek tarif pengisian umum.
3. Catat konsumsi BBM mobil Anda saat ini dari pengisian penuh.
4. Hitung biaya per km untuk masing-masing mobil dengan rumus di atas.
5. Kalikan dengan jarak bulanan, lalu tambahkan biaya perawatan, asuransi, dan cicilan.

Anda juga bisa membaca contoh pembahasan khusus di [biaya per km Geely EX2 Max vs mobil bensin](/artikel/biaya-per-km-geely-ex2-max-vs-mobil-bensin/). Untuk melihat model yang cocok dengan pemakaian harian Anda, buka halaman [Geely EX2](/model/geely-ex2/).

## Pertanyaan yang sering diajukan

### Apakah mobil listrik pasti lebih hemat dari mobil bensin?
Tidak ada jawaban pasti untuk semua orang. Hasilnya bergantung pada tarif listrik, harga BBM, jarak tempuh, dan tempat Anda mengisi daya.

### Dari mana saya mendapatkan konsumsi kWh per km?
Bagi kapasitas baterai dengan jarak tempuh nyata, atau baca angka konsumsi di layar mobil saat dipakai. Angka dari pemakaian nyata lebih bisa diandalkan daripada klaim brosur.

### Apakah tarif SPKLU sama dengan tarif listrik rumah?
Biasanya tidak sama, dan tarif SPKLU ditentukan penyedia layanan. Cek aplikasinya sebelum menghitung.

### Apakah biaya perawatan mobil listrik lebih murah?
Beberapa komponen mesin bensin tidak ada, tetapi ban, rem, dan suspensi tetap perlu dirawat. Tanyakan ke sales untuk jadwal servis dan perkiraan biaya terbaru.

### Bagaimana jika jarak tempuh saya sering berubah?
Hitung dengan beberapa skenario, misalnya jarak rendah, sedang, dan tinggi. Dengan begitu Anda melihat rentang biaya, bukan hanya satu angka.

### Bisakah sales membantu menghitungnya?
Bisa. Kirim jarak harian dan jenis mobil Anda sekarang, lalu saya bantu menyusun perkiraannya.

Panduan terkait yang bisa Anda baca: [Mobil Listrik Pertama](/lp/mobil-listrik-pertama/).

## Kesimpulan

Menghitung biaya operasional itu mudah jika Anda memisahkan energi dari biaya lainnya. Pakai rumus biaya per km, isi dengan angka Anda sendiri, lalu tambahkan perawatan, asuransi, dan cicilan. Hasilnya akan jauh lebih berguna daripada angka umum.

Mau saya bantu hitungkan sesuai rute harian Anda? [Chat saya lewat WhatsApp di halaman kontak](/kontak/), kirim jarak per hari dan tarif listrik rumah, lalu kita susun perkiraannya bersama.
