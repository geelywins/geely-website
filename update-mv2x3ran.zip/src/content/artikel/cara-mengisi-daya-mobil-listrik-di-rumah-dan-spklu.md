---
title: "Cara Mengisi Daya Mobil Listrik di Rumah dan SPKLU untuk Pemula"
description: "Panduan cara mengisi daya mobil listrik di rumah dan SPKLU: beda pengisian AC dan DC, persiapan instalasi, serta etika antre yang perlu Anda tahu sebelum mulai."
date: 2026-10-07
category: "Panduan EV"
tags: ["cara mengisi daya mobil listrik", "spklu", "wallbox", "charging di rumah", "mobil listrik geely", "geely ev", "geely indonesia", "mobil listrik kompak", "pengisian ac dan dc"]
draft: true
---

Cara mengisi daya mobil listrik ada dua: pengisian AC yang lambat dan cocok dilakukan di rumah pada malam hari, serta pengisian cepat DC di SPKLU untuk perjalanan jauh. Dengan memahami perbedaan keduanya, Anda bisa mengatur waktu pengisian sehingga mobil selalu siap dipakai tanpa rasa cemas.

Saya Wins, Sales Consultant Geely di Jakarta dan BSD City. Kekhawatiran paling sering saya dengar dari calon pemilik mobil listrik adalah soal pengisian. Wajar, karena kebiasaannya berbeda dari mampir ke pom bensin. Kabar baiknya, polanya mudah dipelajari. Panduan ini bersifat umum, jadi untuk instalasi listrik tetap konsultasikan dengan teknisi dan PLN.

## Dua jenis pengisian: AC dan DC

Bayangkan pengisian AC seperti mengisi daya ponsel semalaman, dan pengisian DC seperti mengisi cepat saat Anda sedang terburu-buru. Keduanya punya peran masing-masing.

| Hal yang dibandingkan | Pengisian AC | Pengisian DC |
|---|---|---|
| Kecepatan | Lebih lambat | Jauh lebih cepat |
| Tempat umum | Rumah, kantor, pusat belanja | SPKLU tertentu |
| Cocok untuk | Pemakaian harian | Perjalanan jauh |
| Waktu yang ideal | Malam hari atau saat parkir lama | Saat istirahat di perjalanan |

Sebagai gambaran, Geely EX2 Max memakai baterai LFP 40,8 kWh. Menurut klaim, pengisian AC dari 10% ke 100% memerlukan sekitar 6,5 jam, sedangkan pengisian cepat DC dari 30% ke 80% sekitar 25 menit. Waktu nyata bisa berbeda karena dipengaruhi daya pengisi, suhu, dan kondisi baterai.

## Mengisi daya di rumah

Pengisian di rumah adalah cara paling praktis bagi kebanyakan pemilik. Mobil diparkir, kabel disambungkan, lalu Anda beristirahat. Pagi harinya mobil sudah siap.

### Persiapan sebelum memasang

Lakukan langkah-langkah ini sebelum mobil tiba.

1. Cek daya listrik rumah dan kondisi instalasinya bersama teknisi.
2. Tentukan titik parkir yang dekat dengan sumber listrik dan aman dari hujan.
3. Tanyakan pilihan pengisi daya dinding atau wallbox yang sesuai.
4. Pakai perangkat resmi dan pemasangan oleh teknisi berpengalaman.
5. Hindari sambungan kabel sembarangan atau kabel colokan yang tidak layak.

Soal tipe colokan, saya belum bisa menyebutkannya secara pasti karena belum terverifikasi. Tanyakan ke sales untuk informasi yang akurat. Panduan lebih spesifik untuk satu model ada di [cara mengisi daya Geely EX2 Max di rumah](/artikel/cara-mengisi-daya-geely-ex2-max-di-rumah/).

### Kebiasaan yang membantu

- Biasakan mengisi saat malam atau ketika mobil parkir lama.
- Tidak perlu menunggu baterai hampir kosong. Mengisi sedikit-sedikit itu normal.
- Pantau indikator pengisian pada layar atau aplikasi mobil.
- Pastikan area sekitar kabel tidak basah atau terhalang barang.

## Mengisi daya di SPKLU

SPKLU adalah singkatan dari Stasiun Pengisian Kendaraan Listrik Umum. Anda akan memakainya terutama saat bepergian jauh, atau ketika tidak sempat mengisi di rumah.

### Sebelum berangkat

Cek lokasi dan ketersediaan lewat aplikasi penyedia layanan. Siapkan juga akun dan metode pembayaran supaya tidak panik saat tiba. Jika rute Anda panjang, rencanakan titik berhenti dengan jarak yang aman dari kapasitas baterai. Contoh perencanaan untuk perjalanan jauh ada di [mudik dan perjalanan jauh dengan Geely EX2 Max](/artikel/mudik-dan-perjalanan-jauh-dengan-geely-ex2-max/).

### Saat di lokasi

- Parkir sesuai arahan dan jangan menghalangi unit lain.
- Hubungkan kabel dengan tenang, lalu pastikan pengisian benar-benar berjalan.
- Manfaatkan waktu untuk makan, salat, atau ke toilet.
- Segera pindahkan mobil setelah pengisian cukup, terutama jika ada antrean.

Etika ini kecil, tetapi sangat membantu pengguna lain. Detail pengisian cepat ada di [pengisian cepat DC Geely EX2 Max 30-80% sekitar 25 menit](/artikel/pengisian-cepat-dc-geely-ex2-max-30-80-persen-25-menit/).

## Tips menjaga baterai tetap sehat

Baterai adalah komponen penting, jadi rawatlah dengan kebiasaan sederhana berikut.

- Tidak selalu mengisi sampai penuh, kecuali untuk perjalanan jauh.
- Parkir di tempat teduh bila memungkinkan.
- Ikuti anjuran buku manual dan arahan dealer.
- Hindari memaksa pengisian cepat terus-menerus bila tidak diperlukan.

Mobil Geely EX2 Max memakai baterai LFP, jenis yang dikenal stabil. Penjelasannya ada di [baterai LFP 40,8 kWh Geely EX2 Max](/artikel/baterai-lfp-40-8-kwh-geely-ex2-max-aman-dan-tahan-lama/). Untuk informasi garansi, tanyakan ke sales karena ketentuannya bisa diperbarui.

## Menyesuaikan pengisian dengan gaya hidup

Pola pengisian terbaik berbeda untuk setiap orang. Jika Anda punya garasi, pengisian di rumah hampir selalu cukup. Jika tinggal di apartemen, tanyakan kepada pengelola gedung tentang fasilitas pengisian. Jika sering ke luar kota, kenali SPKLU di rute langganan Anda.

Pertimbangkan juga biaya. Tarif pengisian di rumah dan di tempat umum biasanya tidak sama. Cara menghitungnya dibahas di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/). Jika Anda masih mencari model yang pas, lihat [Geely EX2](/model/geely-ex2/) atau [Geely EX5](/model/geely-ex5/).

## Kesalahan umum yang sebaiknya dihindari

Beberapa kebiasaan kecil sering membuat pemilik baru kerepotan. Kenali dari awal supaya Anda tidak mengalaminya.

- Memasang instalasi tanpa konsultasi teknisi listrik.
- Berangkat jauh tanpa mengecek lokasi pengisian di rute.
- Menunggu baterai nyaris kosong baru mencari tempat mengisi.
- Memarkir mobil terlalu lama di SPKLU setelah pengisian selesai.
- Mengabaikan arahan buku manual tentang pengisian.

Jika dibiasakan, semua hal di atas mudah dihindari. Tanyakan ke sales bila ada kondisi khusus di rumah Anda.

## Pertanyaan yang sering diajukan

### Apakah saya wajib memasang pengisi daya di rumah?
Tidak wajib, tetapi sangat membantu bagi pemakaian harian. Konsultasikan kondisi listrik rumah Anda dengan teknisi sebelum memutuskan.

### Berapa lama mengisi daya di rumah?
Untuk Geely EX2 Max, klaim pengisian AC 10-100% sekitar 6,5 jam. Waktu sebenarnya dapat berbeda sesuai kondisi dan daya yang tersedia.

### Apakah pengisian cepat DC merusak baterai?
Pengisian cepat aman dipakai sesuai panduan pabrikan. Namun, sebaiknya jangan dijadikan satu-satunya cara jika Anda bisa mengisi AC di rumah.

### Bagaimana jika SPKLU penuh atau sedang bermasalah?
Siapkan alternatif lokasi dari aplikasi sebelum berangkat. Berangkat dengan baterai yang cukup juga memberi Anda ruang cadangan.

### Apakah boleh mengisi daya saat hujan?
Perangkat yang dirancang sesuai standar umumnya aman, tetapi pastikan area dan kabel tidak tergenang. Ikuti arahan buku manual dan teknisi pemasang.

### Siapa yang bisa membantu memilih pengisi daya rumah?
Tanyakan ke sales dan teknisi listrik tepercaya. Saya juga bisa membantu mengarahkan langkah awalnya.

Panduan terkait yang bisa Anda baca: [Mobil Listrik Pertama](/lp/mobil-listrik-pertama/).

## Kesimpulan

Mengisi daya mobil listrik tidak serumit yang dibayangkan. Gunakan pengisian AC di rumah untuk kebutuhan harian, dan manfaatkan SPKLU untuk perjalanan jauh. Siapkan instalasi dengan teknisi, rencanakan rute, dan jaga etika saat memakai fasilitas umum.

Ingin tahu apakah rumah Anda siap untuk mobil listrik? [Chat saya lewat WhatsApp di halaman kontak](/kontak/), dan saya bantu mengarahkan langkah-langkahnya.
